Elijah Molina, 101272342

Affidavit:
"I attest that I am the sole author of this summitted work and any code borrowed from other sources has been identified by comments placed in my submitted code.
Elijah Molina, 101272342 "

INSTALL INSTRUCTIONS: 
Use command npm install 

LAUNCH INSTRUCTIONS:
Go To File 
Use Command node server.js

TESTING INSTRUCTIONS: 
Go to url address: http://localhost:3000/
Enter Username and Password to Test Guest Account
Enter Username: EMolina and Password: Lol123 to Test Admin Account
Enter Song Name to Search
Press Plus and Minus Buttons to add and remove from playlist

Citations: 
Use of data in html:
https://www.w3schools.com/tags/att_data-.asp

Video Demo: https://youtu.be/RRZcU8qr55M