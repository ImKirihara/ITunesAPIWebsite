document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('register').addEventListener('click', register)
  document.getElementById('signin').addEventListener('click', signIn)
  //add key handler for the document as a whole, not separate elements.
})
